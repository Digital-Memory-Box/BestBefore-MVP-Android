//
//  Room.swift
//  BestBefore_Prototype
//
//  Created by Arya Zaeri on 21.11.2025.
//

import Foundation
import RealmSwift

// This replaces your 'RoomMeta' struct
class RoomObject: Object, ObjectKeyIdentifiable {
    @Persisted(primaryKey: true) var id: ObjectId
    @Persisted var name: String = ""
    @Persisted var createdAt: Date = Date()
    @Persisted var ownerEmail: String?
    
    // Convenience initializer
    convenience init(name: String, ownerEmail: String?) {
        self.init()
        self.name = name
        self.ownerEmail = ownerEmail
        self.createdAt = Date()
    }
}
