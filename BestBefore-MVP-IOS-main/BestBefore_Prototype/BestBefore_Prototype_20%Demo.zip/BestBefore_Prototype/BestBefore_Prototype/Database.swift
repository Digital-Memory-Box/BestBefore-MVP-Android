//
//  Database.swift
//  BestBefore_Prototype
//
//  Created by Arya Zaeri on 13.11.2025.
//

import Foundation
import RealmSwift

final class Database {
    static let shared = Database()
    
    // The local Realm instance
    private var realm: Realm {
        try! Realm()
    }

    private init() {
        // Migration configuration (useful if you change schemas later)
        let config = Realm.Configuration(schemaVersion: 1)
        Realm.Configuration.defaultConfiguration = config
    }

    // MARK: - CRUD Operations

    /// Fetch all rooms, sorted by creation date (newest first)
    func getAllRooms() -> [RoomObject] {
        let results = realm.objects(RoomObject.self).sorted(byKeyPath: "createdAt", ascending: false)
        return Array(results) // Convert Results<RoomObject> to Array
    }

    /// Add a new room
    func addRoom(name: String, ownerEmail: String?) {
        let newRoom = RoomObject(name: name, ownerEmail: ownerEmail)
        try! realm.write {
            realm.add(newRoom)
        }
    }

    /// Update an existing room's name
    func updateRoomName(id: ObjectId, newName: String) {
        if let roomToUpdate = realm.object(ofType: RoomObject.self, forPrimaryKey: id) {
            try! realm.write {
                roomToUpdate.name = newName
            }
        }
    }

    /// Delete a room
    func deleteRoom(id: ObjectId) {
        if let roomToDelete = realm.object(ofType: RoomObject.self, forPrimaryKey: id) {
            try! realm.write {
                realm.delete(roomToDelete)
            }
        }
    }
}

